const msg=`Dear Moi Baby Daal,\n\nHappy Birthday! May your life always be full of happiness and success. ❤️`;
let i=0;
function type(){
 if(i<msg.length){
   document.getElementById('typing').textContent+=msg.charAt(i++);
   setTimeout(type,35);
 }
}
document.getElementById('startBtn').onclick=()=>type();
document.getElementById('cutBtn').onclick=()=>{
 confetti({particleCount:250,spread:180});
 alert('Happy Birthday! 🎉');
};
